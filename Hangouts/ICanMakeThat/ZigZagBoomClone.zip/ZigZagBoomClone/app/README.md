This folder contains the most recent build of the game.

To find old versions, go to this folder:

\CoronaGeek\Hangouts\ICanMakeThat\ZigZagBoomClone\app_old_versions