All of the clipart used in this example is in the public domain and free to use in any way, EXCEPT to sell in a pack or kit of art.

See indivisual sites below for more details.

Lost Garden: 
Goto site for license.
http://lunar.lostgarden.com/labels/free%20game%20graphics.html

Nicu:
All of those images are made by me and are released as Public Domain, so they can be used whitout any restriction.
http://clipart.nicubunu.ro/

Dave Toulouse:
You are free to do anything with these graphics beside selling them. Using them for commercial projects is fine.
www.over00.com